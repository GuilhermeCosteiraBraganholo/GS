export interface Relato {
  id: number;
  local: string;
  tipo: string;
  risco: number;
  descricao: string;
  autor: string;
}
